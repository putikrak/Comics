package com.comics.comic.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.comics.comic.model.Comic;

public interface ComicRepository extends JpaRepository<Comic, Long> {

}