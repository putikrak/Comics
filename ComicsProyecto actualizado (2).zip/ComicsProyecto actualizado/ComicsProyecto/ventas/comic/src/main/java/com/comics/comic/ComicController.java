package com.comics.comic.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.comics.comic.model.Comic;
import com.comics.comic.service.ComicService;

import java.util.List;

@RestController
@RequestMapping("/comics")
public class ComicController {

    @Autowired
    private ComicService service;

    @GetMapping
    public List<Comic> listar(){
        return service.listar();
    }

    @PostMapping
    public Comic guardar(@RequestBody Comic comic){
        return service.guardar(comic);
    }

    @GetMapping("/{id}")
    public Comic buscar(@PathVariable Long id){
        return service.buscarPorId(id);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id){
        service.eliminar(id);
    }  
}