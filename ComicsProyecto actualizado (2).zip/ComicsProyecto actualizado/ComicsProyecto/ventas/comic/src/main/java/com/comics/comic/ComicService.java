package com.comics.comic.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.comics.comic.model.Comic;
import com.comics.comic.repository.ComicRepository;

import java.util.List;

@Service
public class ComicService {

    @Autowired
    private ComicRepository repository;

    public List<Comic> listar(){
        return repository.findAll();
    }

    public Comic guardar(Comic comic){
        return repository.save(comic);
    }

    public Comic buscarPorId(Long id){
        return repository.findById(id).orElse(null);
    }

    public void eliminar(Long id){
        repository.deleteById(id);
    }
}