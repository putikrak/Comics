package com.comics.comic.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "comics")
public class Comic {

    @Id
    @GeneratedValue(strategy = GenerationType.INDENTITY)
    private Long id;
    
    private String nombreComic;
    private String categoriaComic;
    private String autorComic;
    private String editorialComic;
    private int cantidadComics;

    private String nombreCliente;
    private String apellidoCliente;
    private int rutCliente;
    private String idCliente;

    private LocalDate fechaCompra;

    public Comic(){
        
    }

    public Comic(String nombreComic, String categoriaComic, String autorComic, String editorialComic, int cantidadComics, String nombreCliente, String apellidoCliente, int rutCliente, String idCliente, LocalDate fechaCompra){
        this.nombreComic = nombreComic;
        this.categoriaComic = categoriaComic;
        this.autorComic = autorComic;
        this.editorialComic = editorialComic;
        this.cantidadComics = cantidadComics;
        this.nombreCliente = nombreCliente;
        this.apellidoCliente = apellidoCliente;
        this.rutCliente = rutCliente;
        this.idCliente = idCliente;
        this.fechaCompra = fechaCompra;
    }

    public String getNombreComic(){
        return nombreComic;
    }

    public void setNombreComic(String nombreComic){
        this.nombreComic = nombreComic;
    }

    public String getCategoriaComic(){
        return categoriaComic;
    }

    public void setCategoriaComic(String categoriaComic){
        this.categoriaComic = categoriaComic;
    }

    public String getAutorComic(){
        return autorComic;
    }

    public void setAutorComic(String autorComic){
        this.autorComic = autorComic;
    }

    public String getEditorialComic(){
        return editorialComic;
    }

    public void setEditorialComic(String editorialComic){
        this.editorialComic = editorialComic;
    }

    public int getCantidadComics(){
        return cantidadComics;
    }

    public void setCantidadComics(int cantidadComics){
        this.cantidadComics = cantidadComics;
    }

    public String getNombreCliente(){
        return nombreCliente;
    }

    public void setNombreCliente(String nombreCliente){
        this.nombreCliente = nombreCliente;
    }

    public String getApellidoCliente(){
        return apellidoCliente;
    }

    public void setApellidoCliente(String apellidoCliente){
        this.apellidoCliente = apellidoCliente;
    }

    public int getRutCliente(){
        return rutCliente;
    }

    public void setRutCliente(int rutCliente){
        this.rutCliente = rutCliente;
    }

    public String getIdCliente(){
        return idCliente;
    }

    public void setIdCliente(String idCliente){
        this.idCliente = idCliente;
    }

    public LocalDate getFechaCompra(){
        return fechaCompra;
    }

    public void setFechaCompra(LocalDate fechaCompra){
        this.fechaCompra = fechaCompra;
    }
}